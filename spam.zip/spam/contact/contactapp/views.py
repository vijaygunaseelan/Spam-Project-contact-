from django.shortcuts import render
from .models import Contact
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
import re
# Create your views here.
def index(request):
    return render(request, 'index.html')
def ps(messages):
    spam = pickle.load(open('model_pkl','rb'))
    ps = PorterStemmer()
    corpus = []
    for i in range(0, len(messages)):
        review = re.sub('[^a-zA-Z]', ' ', i)
        review = review.lower()
        review = review.split()
        review = [ps.stem(word) for word in review if not word in stopwords.words('english')]
        review = ' '.join(review)
    corpus.append(review)
    cv = CountVectorizer(max_features=2500)
    X = cv.fit_transform(corpus).toarray()
    y_pred = spam.predict(X)
    return y_pred


def contact1(request):
    if request.method == "POST":
        contact = Contact()
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')
        print(type(message))
        print(ps(message.split(' '))) 


   
        contact.name = name
        contact.email = email
        contact.message = message
        contact.save()
        
    return render(request, 'contact1.html')  